# Extract text from images
Web application to extracting text from Image using Java EE
